ant clean doc
scp -r docs/javadoc flaptor@hounder.org:/var/www/lighttpd/opensource.flaptor.com/htdocs/hist4j
